import App from './src/App.jsx';
export default App;
